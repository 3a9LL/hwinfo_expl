#pragma pack(push, 1)
#include <Windows.h>
typedef struct _PHYS_MEM_REGION
{
	ULONG64 Address;
	ULONG64 Size;

} PHYS_MEM_REGION,
*PPHYS_MEM_REGION;

typedef struct _REQUEST_BUFFER
{
	// operation code (see C_* definitions)
	ULONG Code;

	union
	{
		struct // for DRV_CTL_VIRT_MEM_READ and DRV_CTL_PHYS_MEM_READ
		{
			ULONG64 Address;
			ULONG Size;
			UCHAR Data[];

		} MemRead;

		struct // for DRV_CTL_VIRT_MEM_WRITE and DRV_CTL_PHYS_MEM_WRITE
		{
			ULONG64 Address;
			ULONG Size;
			UCHAR Data[];

		} MemWrite;

		struct // for DRV_CTL_PORT_READ
		{
			USHORT Port;
			ULONG Size;
			ULONG64 Val;

		} PortRead;

		struct // for DRV_CTL_PORT_WRITE
		{
			ULONG Port;
			ULONG Size;
			ULONG64 Val;

		} PortWrite;

		struct // for DRV_CTL_MSR_GET
		{
			ULONG Register;
			ULONG64 Value;

		} MsrGet;

		struct // for DRV_CTL_MSR_SET
		{
			ULONG Register;
			ULONG64 Value;

		} MsrSet;
	};

} REQUEST_BUFFER,
*PREQUEST_BUFFER;

#pragma pack(pop)
