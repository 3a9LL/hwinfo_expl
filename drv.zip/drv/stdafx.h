#pragma once
#define _WIN32_WINNT  0x0501

#include <stdio.h>
#include <tchar.h>
#include <conio.h>
#include <windows.h>
#include <Shlwapi.h>

#include "TlHelp32.h"

#include "config.h"
#include "drvcomm.h"

#include "ntdll_defs.h"
#include "ntdll_undocnt.h"
#include "common.h"
#include "memory.h"
#include "service.h"
#include "debug.h"
#include "loader.h"
#include "hexdump.h"

#include "expl_lib.h"

#if !defined(strtoull)

// fucking Microsoft
#define strtoull _strtoui64

#endif

// make crt functions inline
#pragma intrinsic(memcpy)

#define PAGE_SIZE_2MB (2 * 1024 * 1024)

// SMM related model specific registers of Intel
#define IA32_SMRR_PHYSBASE  0x000001F2  // SMRR base address
#define IA32_SMRR_PHYSMASK  0x000001F3  // SMRR range mask
#define IA32_MTRRCAP        0x000000FE  // MTRR capabilities

// sysenter related model specific registers
#define IA32_SYSENTER_CS    0x00000174
#define IA32_SYSENTER_EIP   0x00000176
#define IA32_SYSENTER_ESP   0x00000175

// syscall related model specific registers
#define IA32_LSTAR          0xc0000082