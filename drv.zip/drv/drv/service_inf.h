
BOOL InfLoadDriver(char *lpszServiceName, char *lpszFilePath);

BOOL InfUnloadDriver(char *lpszServiceName);
