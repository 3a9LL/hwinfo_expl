#include "stdafx.h"

int a_phys_mem_read(
	void *addr, unsigned long long size,
	const char *file_path)
{
	int ret = -1;
	unsigned int chunk_size = MEM_IO_BUFF_LEN;
	unsigned long long total = 0, p = 0;

	FILE *f = NULL;
	unsigned char* data = (unsigned char*)malloc(chunk_size);
	if (file_path)
	{
		// create output file
		if ((f = fopen(file_path, "wb")) == NULL)
		{
			printf("ERROR: Unable to create output file \"%s\"\n", file_path);
			goto _end;
		}
	}

	while (p < size)
	{
		unsigned int data_size = min(chunk_size, size - p);

		// read single chunk of memory
		if (!phys_mem_read((unsigned long long)addr + p, data_size, data) != 0)
		{
			printf("ERROR: phys_mem_read() fails\n");
			goto _end;
		}

		if (f)
		{
			// write readed data to file
			if (fwrite(data, 1, data_size, f) != data_size)
			{
				printf("ERROR: fwrite() fails\n");
				goto _end;
			}
		}

		p += data_size;
		total += data_size;
	}

	ret = 0;

_end:

	if (f)
	{
		if (ret == 0)
		{
			printf("%lld bytes written to the \"%s\"\n", total, file_path);
		}

		fclose(f);
	}

	free(data);

	return ret;
}

int a_phys_mem_write(
	void *addr, unsigned long long size,
	const char *file_path)
{
	int ret = -1;
	int chunk_size = sizeof(DWORD);
	unsigned long long total = 0, p = 0;

	if (file_path == NULL)
	{
		return -1;
	}

	FILE *f = NULL;

	struct _stat file_info;

	// get file info on Windows
	if (_stat(file_path, &file_info) != 0)
	{
		printf("ERROR: _stat() fails for file \"%s\"\n", file_path);
		return -1;
	}

	if (file_info.st_size == 0)
	{
		printf("ERROR: \"%s\" file is empty\n", file_path);
		return -1;
	}

	// open input file
	if ((f = fopen(file_path, "rb")) == NULL)
	{
		printf("ERROR: Unable to open input file \"%s\"\n", file_path);
		goto _end;
	}

	size = file_info.st_size;
	DWORD val = 0;
	while (p < size)
	{
		unsigned int data_size = min(chunk_size, size - p);

		if (fseek(f, p, SEEK_SET) != 0)
		{
			printf("ERROR: fseek() fails\n");
			goto _end;
		}

		// read data from file
		val = 0;
		if (fread(&val, 1, data_size, f) != data_size)
		{
			printf("ERROR: fread() fails\n");
			goto _end;
		}
		DWORD old_val = 0;
		if(data_size < chunk_size){
			if (!phys_mem_read((unsigned long long)addr + p, sizeof(DWORD), (unsigned char*)(&old_val))) {
				printf("ERROR: phys_mem_read() fails\n");
				goto _end;
			}
		}
		if (old_val) {
			switch (data_size) {
			case 1:
				val = (old_val & 0xFFFFFF00) | val;
				break;
			case 2:
				val = (old_val & 0xFFFF0000) | val;
				break;
			case 3:
				val = (old_val & 0xFF000000) | val;
				break;
			default:
				break;
			}
		}
		// write single chunk of memory
		if (!phys_mem_write_dword((unsigned long long)addr + p, val) != 0)
		{
			printf("ERROR: phys_mem_write_dword() fails\n");
			goto _end;
		}

		p += data_size;
		total += data_size;
	}

	ret = 0;

_end:

	if (f)
	{
		if (ret == 0)
		{
			printf("%lld bytes written from the \"%s\"\n", total, file_path);
		}

		fclose(f);
	}

	return ret;
}

void usage() {
	printf("--phys - mem - write <addr> --file <in data file> - write from file to phys memory\n"
		"--phys-mem-read <addr> --file <out data file> --length <length> - read from phys memory to file\n"
		"--msr-get <reg> � get MSR (>374)\n"
		"--msr-set <reg> <val> � set MSR (>374)\n"
		"--in-byte <port> - read byte from i/o port\n"
		"--in-word <port> - read word from i/o port\n"
		"--in-dword <port> - read dword from i/o port\n"
		"--out-byte <port> <val> - write byte to i/o port\n"
		"--out-word <port> <val> - write word to i/o port\n"
		"--out-dword <port> <val> - write dword to i/o port\n");
}

int main(int argc, char *argv[])
{
	int ret = -1;
	unsigned long long length;
	const char *data_file = NULL;

	bool ismem_read = false, ismem_write = false;
	void *mem_read = NULL, *mem_write = NULL;

	bool is_msr_read = false, is_msr_write = false;
	DWORD msr_read = NULL, msr_write = NULL;
	unsigned long long msr_value;

	bool is_in = false, is_out = false;
	unsigned short in_port, out_port;
	unsigned long long out_value;
	data_width out_width, in_width;


	// parse command line options
	for (int i = 1; i < argc; i++)
	{
		if (!strcmp(argv[i], "--phys-mem-read") && i < argc - 1)
		{
			// read memory (one page by default)
			mem_read = (void *)strtoull(argv[i + 1], NULL, 16);
			ismem_read = true;

			if (errno != 0)
			{
				printf("ERROR: Invalid address specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--phys-mem-write") && i < argc - 1)
		{
			// write memory (--file option is mandatory)
			mem_write = (void *)strtoull(argv[i + 1], NULL, 16);
			ismem_write = true;

			if (errno != 0)
			{
				printf("ERROR: Invalid address specified\n");
				return -1;
			}

			i += 1;
		}

		else if (!strcmp(argv[i], "--msr-get") && i < argc - 1)
		{
			// msr get
			msr_read = strtoul(argv[i + 1], NULL, 16);
			is_msr_read = true;

			if (errno != 0)
			{
				printf("ERROR: Invalid MSR specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--msr-set") && i < argc - 2)
		{
			// msr set
			msr_write = strtoul(argv[i + 1], NULL, 16);
			is_msr_write = true;
			msr_value = strtoull(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid MSR specified\n");
				return -1;
			}

			i += 2;
		}

		else if (!strcmp(argv[i], "--in-byte") && i < argc - 1)
		{
			// read byte from port
			is_in = true;
			in_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			in_width = U8;

			if (errno != 0)
			{
				printf("ERROR: Invalid in port specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--in-word") && i < argc - 1)
		{
			// read word from port
			is_in = true;
			in_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			in_width = U16;

			if (errno != 0)
			{
				printf("ERROR: Invalid in port specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--in-dword") && i < argc - 1)
		{
			// read dword from port
			is_in = true;
			in_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			in_width = U32;

			if (errno != 0)
			{
				printf("ERROR: Invalid in port specified\n");
				return -1;
			}

			i += 1;
		}

		else if (!strcmp(argv[i], "--out-byte") && i < argc - 2)
		{
			// write byte to port
			is_out = true;
			out_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			out_width = U8;
			out_value = (unsigned long)strtoul(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid out port or value specified\n");
				return -1;
			}

			i += 2;
		}
		else if (!strcmp(argv[i], "--out-word") && i < argc - 2)
		{
			// write word to port
			is_out = true;
			out_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			out_width = U16;
			out_value = (unsigned long)strtoul(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid out port or value specified\n");
				return -1;
			}

			i += 2;
		}
		else if (!strcmp(argv[i], "--out-dword") && i < argc - 2)
		{
			// write dword to port
			is_out = true;
			out_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			out_width = U32;
			out_value = (unsigned long)strtoul(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid out port or value specified\n");
				return -1;
			}

			i += 2;
		}

		else if (!strcmp(argv[i], "--file") && i < argc - 1)
		{
			// file for read or write
			data_file = argv[i + 1];

			i += 1;
		}
		else if (!strcmp(argv[i], "--length") && i < argc - 1)
		{
			// memory read/write length
			length = strtoull(argv[i + 1], NULL, 10);

			if (errno != 0)
			{
				printf("ERROR: Invalid length specified\n");
				return -1;
			}

			i += 1;
		}
		else if ((!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) && i < argc) {
			usage();
			return 0;
		}
		else
		{
			printf("ERROR: Unknown option %s\n", argv[i]);
			return -1;
		}
	}

	if (ismem_read && !(data_file && length))
	{
		printf("ERROR: --length and --file is required for --phys-mem-read\n");
		return -1;
	}

	if (ismem_write && !data_file)
	{
		printf("ERROR: --file is required for --phys-mem-write\n");
		return -1;
	}

	if (is_out) {
		bool wrong_val = false;
		switch (out_width)
		{
		case U8:
			wrong_val = out_value > 0xFF;
			break;
		case U16:
			wrong_val = out_value > 0xFFFF;
			break;
		case U32:
			wrong_val = out_value > 0xFFFFFFFF;
			break;
		default:
			wrong_val = true;
			break;
		}
		if (wrong_val) {
			printf("ERROR: --out: wrong value\n");
			return -1;
		}
	}
	// initialize HAL
	if (init(NULL))
	{
		unsigned long long val = 0;

		if (ismem_read)
		{
			a_phys_mem_read(mem_read, length, data_file);
		}
		else if (ismem_write)
		{
			a_phys_mem_write(mem_write, length, data_file);
		}
		else if (is_msr_read) {
			unsigned long long result;
			if (msr_get(msr_read, &result)) {
				printf("MSR 0x%x = 0x%.16I64x\n", msr_read, result);
			}
			else {
				printf("ERROR: Something wrong with msr reading.\n");
			}
		}
		else if (is_msr_write) {
			if (msr_set(msr_write, msr_value)) {
				printf("MSR 0x%x was rewritten to 0x%.16I64x\n", msr_read, msr_value);
			}
			else {
				printf("ERROR: Something wrong with msr writting.\n");
			}
		}
		else if (is_in) {
			unsigned long long result;
			if (port_read(in_port, in_width, &result)) {
				switch (in_width)
				{
				case U8:
					printf("Byte from port 0x%x = 0x%.2x\n", in_port, result);
					break;
				case U16:
					printf("Word from port 0x%x = 0x%.4x\n", in_port, result);
					break;
				case U32:
					printf("Dword from port 0x%x = 0x%.8x\n", in_port, result);
					break;
				default:
					printf("Wot?!\n");
					break;
				}
			}
			else {
				printf("ERROR: --in: read error\n");
			}
		}
		else if (is_out) {
			if (port_write(out_port, out_width, out_value)) {
				switch (out_width)
				{
				case U8:
					printf("Byte 0x%.2x written to port 0x%x\n", out_value, out_port);
					break;
				case U16:
					printf("Word 0x%.4x written to port 0x%x\n", out_value, out_port);
					break;
				case U32:
					printf("Dword 0x%.8x written to port 0x%x\n", out_value, out_port);
					break;
				default:
					printf("Wot?!\n");
					break;
				}
			}
			else {
				printf("ERROR: --out: write error\n");
			}
		}
		else
		{
			// run exploitation
			// ret = exploit(&target, &context, 0, false);
		}
	_end:
		// uninitialize HAL
		uninit();
	}
	else
	{
		printf("ERROR: init() fails\n");
	}

#ifdef WIN32

	ExitProcess(0);

#endif

	return ret;
}

