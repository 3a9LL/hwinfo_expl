#include "stdafx.h"

typedef void(*SMM_PROC)(void);

#define MEM_IO_BUFF_LEN (PAGE_SIZE * 16)

int a_phys_mem_read(
	void *addr, unsigned long long size,
	const char *file_path)
{
	int ret = -1;
	int chunk_size = MEM_IO_BUFF_LEN;
	unsigned long long total = 0, p = 0;

	FILE *f = NULL;
	unsigned char* data = (unsigned char*)malloc(chunk_size);
	if (file_path)
	{
		// create output file
		if ((f = fopen(file_path, "wb")) == NULL)
		{
			printf("ERROR: Unable to create output file \"%s\"\n", file_path);
			goto _end;
		}
	}


	while (p < size)
	{
		unsigned int data_size = min(chunk_size, size - p);

		unsigned long long _addr = (unsigned long long)addr + p;

		// read single chunk of memory
		if (phys_mem_read(_addr, data_size, data + p) != 0)
		{
			printf("ERROR: phys_mem_read fails\n");
			goto _end;
		}

		if (f)
		{
			// write readed data to file
			if (fwrite(data, 1, data_size, f) != data_size)
			{
				printf("ERROR: fwrite() fails\n");
				goto _end;
			}
		}

		if (data == NULL && f == NULL)
		{
			// print memory dump to the console
			hexdump(data, data_size, (unsigned long long)addr + p);
		}

		p += data_size;
		total += data_size;
	}

	ret = 0;

_end:

	if (f)
	{
		if (ret == 0)
		{
			printf("%lld bytes written to the \"%s\"\n", total, file_path);
		}

		fclose(f);
	}

	free(data);

	return ret;
}

int main(int argc, char *argv[])
{
	int ret = -1, target_num = -1;
	unsigned long long length, pml4_addr = 0;
	const char *data_file = NULL;
	void *mem_read = NULL, *mem_write = NULL;

	bool is_msr_read = false, is_msr_write = false;
	DWORD msr_read = NULL, msr_write = NULL;
	unsigned long long msr_value;

	bool is_in = false, is_out = false;
	unsigned short in_port, out_port;
	unsigned long long out_value;
	data_width out_width, in_width;


	// parse command line options
	for (int i = 1; i < argc; i++)
	{
		if (!strcmp(argv[i], "--phys-mem-read") && i < argc - 1)
		{
			// read memory (one page by default)
			mem_read = (void *)strtoull(argv[i + 1], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid address specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--test")) {
			unsigned char* readed = (unsigned char*)malloc(PAGE_SIZE);
			phys_mem_read(0x0f0000, 0x24, readed);
			hexdump(readed, 0x24, 0x0f0000);
			free(readed);
		}
		else if (!strcmp(argv[i], "--phys-mem-write") && i < argc - 1)
		{
			// write memory (--file option is mandatory)
			mem_write = (void *)strtoull(argv[i + 1], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid address specified\n");
				return -1;
			}

			i += 1;
		}

		else if (!strcmp(argv[i], "--msr-get") && i < argc - 1)
		{
			// msr get
			msr_read = strtoul(argv[i + 1], NULL, 16);
			is_msr_read = true;

			if (errno != 0)
			{
				printf("ERROR: Invalid MSR specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--msr-set") && i < argc - 2)
		{
			// msr set
			msr_write = strtoul(argv[i + 1], NULL, 16);
			is_msr_write = true;
			msr_value = strtoull(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid MSR specified\n");
				return -1;
			}

			i += 2;
		}

		else if (!strcmp(argv[i], "--in-byte") && i < argc - 1)
		{
			// read byte from port
			is_in = true;
			in_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			in_width = U8;

			if (errno != 0)
			{
				printf("ERROR: Invalid in port specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--in-word") && i < argc - 1)
		{
			// read word from port
			is_in = true;
			in_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			in_width = U16;

			if (errno != 0)
			{
				printf("ERROR: Invalid in port specified\n");
				return -1;
			}

			i += 1;
		}
		else if (!strcmp(argv[i], "--in-dword") && i < argc - 1)
		{
			// read dword from port
			is_in = true;
			in_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			in_width = U32;

			if (errno != 0)
			{
				printf("ERROR: Invalid in port specified\n");
				return -1;
			}

			i += 1;
		}

		else if (!strcmp(argv[i], "--out-byte") && i < argc - 2)
		{
			// write byte to port
			is_out = true;
			out_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			out_width = U8;
			out_value = (unsigned long)strtoul(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid out port or value specified\n");
				return -1;
			}

			i += 2;
		}
		else if (!strcmp(argv[i], "--out-word") && i < argc - 2)
		{
			// write word to port
			is_out = true;
			out_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			out_width = U16;
			out_value = (unsigned long)strtoul(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid out port or value specified\n");
				return -1;
			}

			i += 2;
		}
		else if (!strcmp(argv[i], "--out-dword") && i < argc - 2)
		{
			// write dword to port
			is_out = true;
			out_port = (unsigned short)strtoul(argv[i + 1], NULL, 16);
			out_width = U32;
			out_value = (unsigned long)strtoul(argv[i + 2], NULL, 16);

			if (errno != 0)
			{
				printf("ERROR: Invalid out port or value specified\n");
				return -1;
			}

			i += 2;
		}

		else if (!strcmp(argv[i], "--file") && i < argc - 1)
		{
			// file for read or write
			data_file = argv[i + 1];

			i += 1;
		}
		else if (!strcmp(argv[i], "--length") && i < argc - 1)
		{
			// memory read/write length
			length = strtoull(argv[i + 1], NULL, 10);

			if (errno != 0)
			{
				printf("ERROR: Invalid length specified\n");
				return -1;
			}

			i += 1;
		}

		else
		{
			printf("ERROR: Unknown option %s\n", argv[i]);
			return -1;
		}
	}

	if (mem_read && length == 0)
	{
		printf("ERROR: --length is required for --phys-mem-read\n");
		return -1;
	}

	if (mem_write && data_file == NULL)
	{
		printf("ERROR: --file is required for --phys-mem-write\n");
		return -1;
	}

	if (is_out) {
		bool wrong_val = false;
		switch (out_width)
		{
		case U8:
			wrong_val = out_value > 0xFF;
			break;
		case U16:
			wrong_val = out_value > 0xFFFF;
			break;
		case U32:
			wrong_val = out_value > 0xFFFFFFFF;
			break;
		default:
			wrong_val = true;
			break;
		}
		if (wrong_val) {
			printf("ERROR: --out: wrong value\n");
			return -1;
		}
	}
	// initialize HAL
	if (init(NULL))
	{
		unsigned long long val = 0;

		if (mem_read)
		{
			unsigned char * data;
			a_phys_mem_read(mem_read, length, data_file);
		}
		else if (mem_write)
		{
			// write memory contents
			//ret = phys_mem_write(&target, mem_write, length, NULL, data_file);
		}
		else if (is_msr_read) {
			unsigned long long result;
			if (msr_get(msr_read, &result)) {
				printf("MSR 0x%x = 0x%.16I64x\n", msr_read, result);
			}
			else {
				printf("ERROR: Something wrong with msr reading.\n");
			}
		}
		else if (is_msr_write) {
			if (msr_set(msr_write, msr_value)) {
				printf("MSR 0x%x was rewritten to 0x%.16I64x\n", msr_read, msr_value);
			}
			else {
				printf("ERROR: Something wrong with msr writting.\n");
			}
		}
		else if (is_in) {
			unsigned long long result;
			if (port_read(in_port, in_width, &result)) {
				switch (in_width)
				{
				case U8:
					printf("Byte from port 0x%x = 0x%.2x\n", in_port, result);
					break;
				case U16:
					printf("Word from port 0x%x = 0x%.4x\n", in_port, result);
					break;
				case U32:
					printf("Dword from port 0x%x = 0x%.8x\n", in_port, result);
					break;
				default:
					printf("Wot?!\n");
					break;
				}
			}
			else {
				printf("ERROR: --in: read error\n");
			}
		}
		else if (is_out) {
			if (port_write(out_port, out_width, out_value)) {
				switch (out_width)
				{
				case U8:
					printf("Byte 0x%.2x written to port 0x%x\n", out_value, out_port);
					break;
				case U16:
					printf("Word 0x%.4x written to port 0x%x\n", out_value, out_port);
					break;
				case U32:
					printf("Dword 0x%.8x written to port 0x%x\n", out_value, out_port);
					break;
				default:
					printf("Wot?!\n");
					break;
				}
			}
			else {
				printf("ERROR: --out: write error\n");
			}
		}
		else
		{
			// run exploitation
			// ret = exploit(&target, &context, 0, false);
		}
	_end:
		// uninitialize HAL
		uninit();
	}
	else
	{
		printf("ERROR: init() fails\n");
	}

#ifdef WIN32

	ExitProcess(0);

#endif

	return ret;
}

