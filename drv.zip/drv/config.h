// name of the driver to install
#define DRIVER_DEFAULT_NAME "HWiNFO64A.sys"

// device name to communicate with the driver
#define DEVICE_NAME L"HWiNFO32"

// driver server name
#define SERVICE_NAME "HWiNFO64A"

// file name of installed driver that will be created in system32/drivers
#define DRIVER_FILE_NAME "HWiNFO64A.sys"
