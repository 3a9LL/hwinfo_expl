#include "stdafx.h"

HANDLE m_hDevice = NULL;
static BOOL m_bStopService = FALSE;

bool init(char *driver_path)
{
	PWSTR lpszDeviceName = L"\\Device\\" DEVICE_NAME;

	if (driver_path == NULL)
	{
		// use default kernel driver file
		driver_path = DRIVER_DEFAULT_NAME;
	}

	if (m_hDevice)
	{
		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Already initialized\n");
		return false;
	}

	m_bStopService = FALSE;

	// try to open device if service was already started
	if (DrvOpenDevice(lpszDeviceName, &m_hDevice))
	{
		return true;
	}

	BOOL bAsService = TRUE;
	{
		char szDestPath[MAX_PATH];
		PVOID Data = NULL;
		DWORD dwDataSize = 0;

		GetSystemDirectory(szDestPath, sizeof(szDestPath));
		lstrcat(szDestPath, "\\drivers\\" DRIVER_FILE_NAME);

		// copy driver to the system directory
		if (!CopyFile(driver_path, szDestPath, FALSE))
		{
			DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Can't copy %s to system32\\drivers\n", driver_path);
		}

		// start service
		if (!(m_bStopService = DrvServiceStart(SERVICE_NAME, szDestPath, NULL)))
		{
			DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Can't load driver using system service\n");
			return false;
		}
	}

	// open device
	if (DrvOpenDevice(lpszDeviceName, &m_hDevice))
	{
		return true;
	}
	else
	{
		DbgMsg(__FILE__, __LINE__, "Error while opening kernel driver device\n");
	}

	// cleanup
	if (m_bStopService)
	{
		DrvServiceStop(SERVICE_NAME);
		m_bStopService = FALSE;
	}

	m_hDevice = NULL;

	return false;
}
//--------------------------------------------------------------------------------------
void uninit(void)
{
	if (m_hDevice)
	{
		CloseHandle(m_hDevice);
		m_hDevice = NULL;
	}

	if (m_bStopService)
	{
		DrvServiceStop(SERVICE_NAME);
		m_bStopService = FALSE;
	}
}
//TODO------------------------------------------------------------------------------------
bool phys_mem_read(unsigned long long address, int size, unsigned char *buff)
{
	if (m_hDevice == NULL)
	{
		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Not initialized\n");
		return false;
	}

	bool bRet = false;
	ZeroMemory(buff, size);

	// address and size for MmMapIoSpace() must be aligned by page boundary
	DWORD64 MapAddress = XALIGN_DOWN(address, PAGE_SIZE);
	DWORD MapSize = XALIGN_UP(size, PAGE_SIZE);

	PUCHAR Data = (PUCHAR)M_ALLOC(MapSize);
	if (Data)
	{
		DWORD dwBytes = 0;
		UCHAR Request[0x100];
		ZeroMemory(&Request, sizeof(Request));

		*(PDWORD64)(Request + 0x00) = MapAddress;
		*(PDWORD)(Request + 0x08) = MapSize;

		// read memory
		if (DeviceIoControl(
			m_hDevice, 0x85FE2608,
			&Request, sizeof(Request), Data, MapSize,
			&dwBytes, NULL))
		{
			// copy memory contents to caller buffer
			CopyMemory(
				buff,
				RVATOVA(Data, address - MapAddress),
				size
			);

			bRet = true;
		}
		else
		{
			DbgMsg(__FILE__, __LINE__, "DeviceIoControl() ERROR %d\n", GetLastError());
		}

		M_FREE(Data);
	}
	else
	{
		DbgMsg(__FILE__, __LINE__, "M_ALLOC() ERROR %d\n", GetLastError());
	}

	return bRet;
}
//TODO+----------------------------------------------------------------------------------
bool phys_mem_write(unsigned long long address, int size, unsigned char *buff)
{
	if (m_hDevice == NULL)
	{
		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Not initialized\n");
		return false;
	}

	bool bRet = false;

	// address and size for MmMapIoSpace() must be aligned by page boundary
	DWORD64 MapAddress = XALIGN_DOWN(address, PAGE_SIZE);
	DWORD MapSize = XALIGN_UP(size, PAGE_SIZE);

	PUCHAR Data = (PUCHAR)M_ALLOC(MapSize);
	if (Data)
	{
		// read original memory contents
		if (phys_mem_read(MapAddress, MapSize, Data))
		{
			DWORD dwBytes = 0;
			UCHAR Request[0x100];
			ZeroMemory(&Request, sizeof(Request));

			// copy memory contents from caller buffer
			CopyMemory(
				RVATOVA(Data, address - MapAddress),
				buff,
				size
			);

			*(PDWORD64)(Request + 0x00) = MapAddress;
			*(PDWORD64)(Request + 0x10) = (DWORD64)Data;
			*(PDWORD)(Request + 0x08) = MapSize;
			*(PDWORD)(Request + 0x0c) = 2;

			// write memory
			if (DeviceIoControl(
				m_hDevice, 0x22280c,
				&Request, sizeof(Request), &Request, sizeof(Request),
				&dwBytes, NULL))
			{
				bRet = true;
			}
			else
			{
				DbgMsg(__FILE__, __LINE__, "DeviceIoControl() ERROR %d\n", GetLastError());
			}
		}

		M_FREE(Data);
	}
	else
	{
		DbgMsg(__FILE__, __LINE__, "M_ALLOC() ERROR %d\n", GetLastError());
	}

	return bRet;
}
//--------------------------------------------------------------------------------------
bool port_read(unsigned short port, data_width size, unsigned long long *val)
{
	if (m_hDevice == NULL)
	{
		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Not initialized\n");
		return false;
	}

	UCHAR Request[0x100];
	ZeroMemory(&Request, sizeof(Request));

	*(PWORD)(Request + 0x00) = port;

	DWORD dwBytes = 0;
	BOOL bStatus = FALSE;

	switch (size)
	{
	case U8:

		// send request to the driver
		bStatus = DeviceIoControl(
			m_hDevice, 0x85FE2614,
			&Request, sizeof(Request), &Request, sizeof(Request),
			&dwBytes, NULL
		);

		break;

	case U16:

		// send request to the driver
		bStatus = DeviceIoControl(
			m_hDevice, 0x85FE2618,
			&Request, sizeof(Request), &Request, sizeof(Request),
			&dwBytes, NULL
		);

		break;

	case U32:

		// send request to the driver
		bStatus = DeviceIoControl(
			m_hDevice, 0x85FE261C,
			&Request, sizeof(Request), &Request, sizeof(Request),
			&dwBytes, NULL
		);

		break;

	default:

		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Invalid data width %d\n", size);
		return false;
	}

	if (bStatus)
	{
		*val = *(PDWORD64)(Request + 0x04);

		return true;
	}
	else
	{
		DbgMsg(__FILE__, __LINE__, "DeviceIoControl() ERROR %d\n", GetLastError());
	}

	return false;
}
//--------------------------------------------------------------------------------------
bool port_write(unsigned short port, data_width size, unsigned long long val)
{
	if (m_hDevice == NULL)
	{
		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Not initialized\n");
		return false;
	}

	UCHAR Request[0x100];
	ZeroMemory(&Request, sizeof(Request));

	*(PWORD)(Request + 0x00) = port;
	*(PDWORD64)(Request + 0x04) = val;

	DWORD dwBytes = 0;
	BOOL bStatus = FALSE;

	switch (size)
	{
	case U8:

		// send request to the driver
		bStatus = DeviceIoControl(
			m_hDevice, 0x85FE2624,
			&Request, sizeof(Request), &Request, sizeof(Request),
			&dwBytes, NULL
		);

		break;

	case U16:

		// send request to the driver
		bStatus = DeviceIoControl(
			m_hDevice, 0x85FE2628,
			&Request, sizeof(Request), &Request, sizeof(Request),
			&dwBytes, NULL
		);

		break;

	case U32:

		// send request to the driver
		bStatus = DeviceIoControl(
			m_hDevice, 0x85FE262C,
			&Request, sizeof(Request), &Request, sizeof(Request),
			&dwBytes, NULL
		);

		break;

	default:

		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Invalid data width %d\n", size);
		return false;
	}

	if (bStatus)
	{
		return true;
	}
	else
	{
		DbgMsg(__FILE__, __LINE__, "DeviceIoControl() ERROR %d\n", GetLastError());
	}

	return false;
}
//--------------------------------------------------------------------------------------
bool msr_get(unsigned int reg, unsigned long long *val)
{
	if (m_hDevice == NULL)
	{
		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Not initialized\n");
		return false;
	}

	DWORD dwBytes = 0;
	UCHAR Request[0x100];
	ZeroMemory(&Request, sizeof(Request));

	*(PDWORD)(Request + 0x00) = reg;

	// send request to the driver
	if (DeviceIoControl(
		m_hDevice, 0x85FE2604,
		&Request, sizeof(Request), &Request, sizeof(Request),
		&dwBytes, NULL))
	{
		*val = *(unsigned long long*)(Request + 0x08);
		return true;
	}
	else
	{
		DbgMsg(__FILE__, __LINE__, "DeviceIoControl() ERROR %d\n", GetLastError());
	}

	return false;
}
//--------------------------------------------------------------------------------------
bool msr_set(unsigned int reg, unsigned long long val)
{
	if (m_hDevice == NULL)
	{
		DbgMsg(__FILE__, __LINE__, __FUNCTION__"() ERROR: Not initialized\n");
		return false;
	}

	DWORD dwBytes = 0;
	UCHAR Request[0x100];
	ZeroMemory(&Request, sizeof(Request));

	*(PDWORD)(Request + 0x00) = reg;
	*(PDWORD)(Request + 0x08) = val;

	// send request to the driver
	if (DeviceIoControl(
		m_hDevice, 0x85FE267C,
		&Request, sizeof(Request), &Request, sizeof(Request),
		&dwBytes, NULL))
	{
		return true;
	}
	else
	{
		DbgMsg(__FILE__, __LINE__, "DeviceIoControl() ERROR %d\n", GetLastError());
	}

	return false;
}
