
void DbgMsg(char *lpszFile, int Line, char *lpszMsg, ...);
