#pragma once
#define PAGE_SIZE 0x1000


typedef enum _data_width
{
	U8, U16, U32, U64

} data_width;

#ifdef __cplusplus

extern "C"
{

#endif


	// initialize kernel driver
	bool init(char *driver_path);

	// unload kernel driver
	void uninit(void);

	// read physical memory at given address
	bool phys_mem_read(unsigned long long address, int size, unsigned char *buff);

	// write physical memory at given address
	bool phys_mem_write(unsigned long long address, int size, unsigned char *buff);

	// read value from I/O port
	bool port_read(unsigned short port, data_width size, unsigned long long *val);

	// write value to I/O port
	bool port_write(unsigned short port, data_width size, unsigned long long val);

	// get model specific register value
	bool msr_get(unsigned int reg, unsigned long long *val);

	// set model specific register value
	bool msr_set(unsigned int reg, unsigned long long val);


#ifdef __cplusplus

}

#endif
